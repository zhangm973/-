function nav() {
    // var menu = document.getElementsByClassName('menu')[0];
    //
    // var libh = document.getElementsByClassName('libh')[0];
    //
    // var li = document.querySelectorAll('.menu li');

    // var menu_li_list = document.getElementsByClassName('menu_li_list')[0];
    //
    // var menu_li_list_div = document.querySelectorAll('.menu_li_list div');
    //
    // menu.onmouseover = function (ev) {
    //
    //     menu_li_list.style.display = 'inline-block';
    //
    //     var ev = ev || window.event;
    //
    //     var target = ev.target || ev.srcElement;
    //
    //     while(target !== menu ){
    //
    //         if(target.tagName.toLowerCase() == 'li'){
    //
    //             for (var i = 0; i < menu_li_list_div.length; i++){
    //
    //                 if ( Math.round((target.offsetLeft - libh.offsetLeft - libh.clientWidth) / li[i].clientWidth) == i){
    //
    //                     menu_li_list_div[i].style.display = 'block';
    //
    //                 } else {
    //
    //                     menu_li_list_div[i].style.display = 'none';
    //
    //                 }
    //
    //                 menu_li_list_div[i].style.left = target.offsetLeft + 'px';
    //             }
    //         }
    //         target = target.parentNode;
    //     }
    //
    // }
    // menu_li_list.onmouseout = function () {
    //
    //     menu_li_list.style.display = 'none';
    //
    // }

//>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>选卡、验证




    // var input=document.getElementById('inpu').getElementsByTagName('input')[0];
    // var input2=document.getElementById('inpu1').getElementsByTagName('input')[0];
    //
    // var reg=/^(1[3578]\d)\d{4}(\d{4})$/;
    // input.onblur=function(){
    //     var strNum=input.value;
    //     var ist=reg.test(strNum);
    //     input2.onclick=function(){
    //         if(ist){
    //         }else{
    //             alert('手机号错误')
    //         }
    //     }
    // }
    // var isTure=false;
    // var str="";



}
nav();